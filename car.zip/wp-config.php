<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u772054074_carboat' );

/** MySQL database username */
define( 'DB_USER', 'u772054074_carboat' );

/** MySQL database password */
define( 'DB_PASSWORD', 'Pass@word1' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '}g_y`dq#8058T1C3M;s#kj/& 9~^Kr=rYZ<KY!99Hi3: }X19V5`San16=w9 )7N' );
define( 'SECURE_AUTH_KEY',  'VQ8/O&6BPJ[rivfVHE:}~`E&7zw&G1TJdF]mAG|X<*`O4s +*h7ZL00Wf]W+*#/T' );
define( 'LOGGED_IN_KEY',    '7cQ+J6B`#}{thXX8x3ZwfTJUMiB2EF<-`gvg-D+COv#f.+A>sJIkBc52n+diXv< ' );
define( 'NONCE_KEY',        ' A.s%+1JwzNaSr HvF@s3xUBr`8L0)^wq<N-o`z,vULSc8,oY#1;l9OnO(lt!=]E' );
define( 'AUTH_SALT',        '3_j}Un1 i`ZVqTH<7jSTPur0rv~%`XsAmmK.BylkfSp6PyA}x= L`x{8yORbJQ7*' );
define( 'SECURE_AUTH_SALT', 'k(Y1<)FiHY;*xm,HP<8, 8A&g)R&a9#s[niPj2T1c#_Obuq;:m.# KkK&00_}m~l' );
define( 'LOGGED_IN_SALT',   'D-$)dGSz|b$^~y-C>7zDd>iK`mr]hf`oud/GaxqD38hYHNe).U~7._KGe0<gsDT9' );
define( 'NONCE_SALT',       'UWW%x.sVU t7zw0Tle[LOynj~lpu_&opgF=F[N]a&yaR7s]tG>ShioMsFf|ggDpW' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
